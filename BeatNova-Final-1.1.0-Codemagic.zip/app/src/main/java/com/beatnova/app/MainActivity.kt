package com.beatnova.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray

private val Background = Color(0xFF090A0F)
private val SurfaceDark = Color(0xFF14151C)
private val SurfaceSoft = Color(0xFF1B1C25)
private val TextMain = Color(0xFFF6F6FA)
private val TextMuted = Color(0xFFA7A8B4)
private val Accent = Color(0xFFB56CFF)
private val Accent2 = Color(0xFF5C7CFF)

private data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val audioUrl: String,
    val coverUrl: String = ""
)

private object SupabaseRepository {
    private val client = OkHttpClient()

    suspend fun getSongs(): Result<List<Song>> = withContext(Dispatchers.IO) {
        val baseUrl = BuildConfig.SUPABASE_URL.trimEnd('/')
        val key = BuildConfig.SUPABASE_ANON_KEY
        if (baseUrl.isBlank() || key.isBlank()) {
            return@withContext Result.failure(IllegalStateException("SUPABASE_CONFIG_MISSING"))
        }
        try {
            val request = Request.Builder()
                .url("$baseUrl/rest/v1/songs?select=*")
                .addHeader("apikey", key)
                .addHeader("Authorization", "Bearer $key")
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("HTTP_${response.code}"))
                }
                val json = JSONArray(response.body?.string().orEmpty())
                val result = buildList {
                    for (i in 0 until json.length()) {
                        val item = json.getJSONObject(i)
                        val audio = item.optString("audio_url")
                        if (audio.isNotBlank()) {
                            add(
                                Song(
                                    id = item.optString("id", i.toString()),
                                    title = item.optString("title", "آهنگ بدون نام"),
                                    artist = item.optString("artist", "هنرمند ناشناس"),
                                    audioUrl = audio,
                                    coverUrl = item.optString("cover_url", "")
                                )
                            )
                        }
                    }
                }
                Result.success(result)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BeatNovaApp() }
    }
}

@Composable
private fun BeatNovaApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    var tab by remember { mutableStateOf(0) }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var current by remember { mutableStateOf<Song?>(null) }
    var playing by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    val scope = rememberCoroutineScope()

    fun loadSongs() {
        scope.launch {
            loading = true
            error = null
            SupabaseRepository.getSongs()
                .onSuccess { songs = it }
                .onFailure { error = it.message ?: "UNKNOWN" }
            loading = false
        }
    }

    fun playSong(song: Song) {
        current = song
        player.setMediaItem(MediaItem.fromUri(song.audioUrl))
        player.prepare()
        player.play()
        playing = true
    }

    fun togglePlayback() {
        if (player.isPlaying) {
            player.pause()
            playing = false
        } else if (current != null) {
            player.play()
            playing = true
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) playing = false
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(Unit) { loadSongs() }

    val visibleSongs = songs.filter {
        query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true)
    }
    val librarySongs = songs.filter { it.id in favorites }

    MaterialTheme(colorScheme = MaterialTheme.colorScheme.copy(background = Background)) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.navigationBarsPadding(),
                    containerColor = Color(0xFF101118)
                ) {
                    val labels = listOf("خانه", "جستجو", "کتابخانه", "تنظیمات")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Search, Icons.Default.LibraryMusic, Icons.Default.Settings)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Background)
                    .padding(padding)
            ) {
                when (tab) {
                    0 -> HomeScreen(
                        songs = visibleSongs,
                        current = current,
                        playing = playing,
                        loading = loading,
                        error = error,
                        onRefresh = ::loadSongs,
                        onPlay = ::playSong,
                        favorites = favorites,
                        onFavorite = { id -> favorites = if (id in favorites) favorites - id else favorites + id },
                        onToggle = ::togglePlayback
                    )
                    1 -> SearchScreen(
                        query = query,
                        onQueryChange = { query = it },
                        songs = visibleSongs,
                        current = current,
                        onPlay = ::playSong,
                        favorites = favorites,
                        onFavorite = { id -> favorites = if (id in favorites) favorites - id else favorites + id }
                    )
                    2 -> LibraryScreen(
                        songs = librarySongs,
                        current = current,
                        onPlay = ::playSong,
                        favorites = favorites,
                        onFavorite = { id -> favorites = if (id in favorites) favorites - id else favorites + id }
                    )
                    3 -> SettingsScreen()
                }
                if (current != null) {
                    MiniPlayer(song = current!!, playing = playing, onToggle = ::togglePlayback)
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    songs: List<Song>, current: Song?, playing: Boolean, loading: Boolean, error: String?,
    onRefresh: () -> Unit, onPlay: (Song) -> Unit, favorites: Set<String>,
    onFavorite: (String) -> Unit, onToggle: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.statusBarsPadding().fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("BeatNova", color = TextMain, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                Text("صدای مورد علاقه‌ات، همیشه آنلاین", color = TextMuted, style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "به‌روزرسانی", tint = TextMain)
            }
        }

        Card(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).shadow(8.dp, RoundedCornerShape(26.dp)),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                Modifier.fillMaxWidth().background(
                    Brush.linearGradient(listOf(Color(0xFF24244A), Color(0xFF3A2158), Color(0xFF161A35)))
                ).padding(22.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(Color.White.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MusicNote, null, tint = TextMain, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.size(14.dp))
                        Column {
                            Text("موسیقی آنلاین", color = TextMain, fontWeight = FontWeight.Bold)
                            Text("کتابخانه‌ای که با تو رشد می‌کند", color = Color(0xFFD8D7E7), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("پخش مستقیم و سریع", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(5.dp))
                    Text("آهنگ‌های مجاز خودت را از Supabase پخش کن.", color = Color(0xFFD0D0DC))
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.clip(CircleShape).background(Color.White.copy(alpha = .14f)).padding(horizontal = 12.dp, vertical = 7.dp)) {
                            Text("${songs.size} آهنگ", color = TextMain, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.size(10.dp))
                        if (current != null) {
                            IconButton(onClick = onToggle, modifier = Modifier.size(42.dp).clip(CircleShape).background(TextMain)) {
                                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color(0xFF171724))
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        if (error != null) {
            ConfigCard(error = error)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("آخرین آهنگ‌ها", color = TextMain, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("${songs.size} مورد", color = TextMuted, style = MaterialTheme.typography.bodySmall)
        }
        if (loading) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
        } else if (songs.isEmpty()) {
            EmptyState()
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
                items(songs, key = { it.id }) { song ->
                    SongRow(song, current?.id == song.id, song.id in favorites, onPlay, onFavorite)
                }
            }
        }
    }
}

@Composable
private fun SearchScreen(query: String, onQueryChange: (String) -> Unit, songs: List<Song>, current: Song?, onPlay: (Song) -> Unit, favorites: Set<String>, onFavorite: (String) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("جستجو", color = TextMain, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
        Text("آهنگ یا خواننده را پیدا کن", color = TextMuted)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = query, onValueChange = onQueryChange, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("مثلاً نام آهنگ یا هنرمند") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(14.dp))
        if (songs.isEmpty()) EmptyState() else LazyColumn(Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 20.dp)) {
            items(songs, key = { it.id }) { song -> SongRow(song, current?.id == song.id, song.id in favorites, onPlay, onFavorite) }
        }
    }
}

@Composable
private fun LibraryScreen(songs: List<Song>, current: Song?, onPlay: (Song) -> Unit, favorites: Set<String>, onFavorite: (String) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(18.dp))
        Text("کتابخانه", color = TextMain, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
        Text("آهنگ‌های مورد علاقه تو", color = TextMuted)
        Spacer(Modifier.height(12.dp))
        if (songs.isEmpty()) EmptyState() else LazyColumn(Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 20.dp)) {
            items(songs, key = { it.id }) { song -> SongRow(song, current?.id == song.id, song.id in favorites, onPlay, onFavorite) }
        }
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(20.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("تنظیمات", color = TextMain, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
        Text("BeatNova", color = TextMuted)
        Spacer(Modifier.height(22.dp))
        SettingCard("وضعیت سرویس", if (BuildConfig.SUPABASE_URL.isBlank()) "Supabase هنوز تنظیم نشده" else "Supabase آماده است", Icons.Default.Wifi)
        Spacer(Modifier.height(10.dp))
        SettingCard("نسخه برنامه", "1.1.0 • Android 7.0+", Icons.Default.Settings)
        Spacer(Modifier.height(10.dp))
        SettingCard("پخش‌کننده", "Media3 / ExoPlayer", Icons.Default.PlayArrow)
        Spacer(Modifier.height(20.dp))
        Text("BeatNova برای پخش محتوای قانونی و دارای مجوز طراحی شده است.", color = TextMuted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SettingCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(SurfaceSoft), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Accent) }
            Spacer(Modifier.size(13.dp))
            Column {
                Text(title, color = TextMain, fontWeight = FontWeight.Bold)
                Text(value, color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ConfigCard(error: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF211B2B))) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Wifi, null, tint = Accent)
            Spacer(Modifier.size(12.dp))
            Column {
                Text(if (error == "SUPABASE_CONFIG_MISSING") "اتصال آنلاین تنظیم نشده" else "اتصال به سرور ناموفق بود", color = TextMain, fontWeight = FontWeight.Bold)
                Text(if (error == "SUPABASE_CONFIG_MISSING") "SUPABASE_URL و SUPABASE_ANON_KEY را در Codemagic تنظیم کن." else "لطفاً آدرس و دسترسی Supabase را بررسی کن.", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun EmptyState() {
    Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(70.dp).clip(CircleShape).background(SurfaceSoft), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Accent, modifier = Modifier.size(32.dp)) }
            Spacer(Modifier.height(12.dp))
            Text("هنوز آهنگی اینجا نیست", color = TextMain, fontWeight = FontWeight.Bold)
            Text("وقتی آهنگ‌ها در جدول songs قرار بگیرند، اینجا نمایش داده می‌شوند.", color = TextMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun SongRow(song: Song, selected: Boolean, favorite: Boolean, onPlay: (Song) -> Unit, onFavorite: (String) -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp).clickable { onPlay(song) },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF202033) else SurfaceDark)
    ) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(Color(0xFF34345A), Color(0xFF1D2345)))), contentAlignment = Alignment.Center) {
                Icon(if (selected) Icons.Default.MusicNote else Icons.Default.LibraryMusic, null, tint = TextMain, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = TextMain, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = { onFavorite(song.id) }) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Accent else TextMuted) }
            Box(Modifier.size(38.dp).clip(CircleShape).background(if (selected) Accent else SurfaceSoft), contentAlignment = Alignment.Center) {
                Icon(if (selected) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = if (selected) Color.White else TextMain)
            }
        }
    }
}

@Composable
private fun MiniPlayer(song: Song, playing: Boolean, onToggle: () -> Unit) {
    Surface(color = Color(0xFF171822), tonalElevation = 8.dp) {
        Column {
            Divider(color = Color.White.copy(alpha = .06f))
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Accent2, Accent))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.MusicNote, null, tint = Color.White)
                }
                Spacer(Modifier.size(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = TextMain, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = TextMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                }
                IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = TextMain) }
            }
        }
    }
}
