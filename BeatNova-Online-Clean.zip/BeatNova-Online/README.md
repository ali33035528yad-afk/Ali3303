# BeatNova

Android music streaming starter with Jetpack Compose, Media3 ExoPlayer, and Supabase REST.

## Supabase table
Create a table named `songs` with:

- `id` (text or uuid)
- `title` (text)
- `artist` (text)
- `audio_url` (text)
- `cover_url` (text, optional)

Enable a SELECT policy for the public/anon role if the catalog is public.

Example row:

```json
{
  "id": "1",
  "title": "My Song",
  "artist": "My Artist",
  "audio_url": "https://YOUR_PROJECT.supabase.co/storage/v1/object/public/songs/my-song.mp3",
  "cover_url": "https://YOUR_PROJECT.supabase.co/storage/v1/object/public/covers/my-cover.jpg"
}
```

Only upload music you own or are licensed to distribute.

## Codemagic
Add these environment variables:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

Do not put the Supabase service-role key in the Android app.
