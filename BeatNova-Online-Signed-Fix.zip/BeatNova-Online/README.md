# BeatNova Online

Release build is configured to use Codemagic Android signing.

Important: in Codemagic, the `android_signing` reference in `codemagic.yaml` must match the Reference name of your uploaded Android keystore. The release APK is signed from `CM_KEYSTORE_PATH`, `CM_KEYSTORE_PASSWORD`, `CM_KEY_ALIAS`, and `CM_KEY_PASSWORD`.
