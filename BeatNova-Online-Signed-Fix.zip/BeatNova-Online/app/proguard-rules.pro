# BeatNova release rules
