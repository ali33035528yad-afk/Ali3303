package com.beatnova.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray

private data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val audioUrl: String,
    val coverUrl: String = ""
)

private object SupabaseRepository {
    private val client = OkHttpClient()

    suspend fun getSongs(): Result<List<Song>> = withContext(Dispatchers.IO) {
        val baseUrl = BuildConfig.SUPABASE_URL.trimEnd('/')
        val key = BuildConfig.SUPABASE_ANON_KEY
        if (baseUrl.isBlank() || key.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Supabase is not configured yet."))
        }

        try {
            val request = Request.Builder()
                .url("$baseUrl/rest/v1/songs?select=*")
                .addHeader("apikey", key)
                .addHeader("Authorization", "Bearer $key")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Supabase error: HTTP ${response.code}")
                    )
                }

                val body = response.body?.string().orEmpty()
                val json = JSONArray(body)
                val songs = buildList {
                    for (i in 0 until json.length()) {
                        val item = json.getJSONObject(i)
                        val audio = item.optString("audio_url")
                        if (audio.isNotBlank()) {
                            add(
                                Song(
                                    id = item.optString("id", i.toString()),
                                    title = item.optString("title", "Untitled"),
                                    artist = item.optString("artist", "Unknown artist"),
                                    audioUrl = audio,
                                    coverUrl = item.optString("cover_url", "")
                                )
                            )
                        }
                    }
                }
                Result.success(songs)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BeatNovaApp() }
    }
}

@Composable
private fun BeatNovaApp() {
    val context = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build()
    }

    var selectedTab by remember { mutableStateOf(0) }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var currentSong by remember { mutableStateOf<Song?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun loadSongs() {
        scope.launch {
            isLoading = true
            error = null
            val result = SupabaseRepository.getSongs()
            result.onSuccess { songs = it }
                .onFailure { error = it.message }
            isLoading = false
        }
    }

    fun playSong(song: Song) {
        currentSong = song
        player.setMediaItem(MediaItem.fromUri(song.audioUrl))
        player.prepare()
        player.play()
        isPlaying = true
    }

    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    LaunchedEffect(Unit) { loadSongs() }

    val filteredSongs = songs.filter {
        query.isBlank() ||
            it.title.contains(query, ignoreCase = true) ||
            it.artist.contains(query, ignoreCase = true)
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val labels = listOf("خانه", "جستجو", "کتابخانه", "تنظیمات")
                val icons = listOf(
                    Icons.Default.Home,
                    Icons.Default.Search,
                    Icons.Default.LibraryMusic,
                    Icons.Default.Settings
                )
                labels.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(icons[index], contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF0B0B0F))
        ) {
            when (selectedTab) {
                0 -> HomeScreen(
                    songs = filteredSongs,
                    currentSong = currentSong,
                    isPlaying = isPlaying,
                    isLoading = isLoading,
                    error = error,
                    onRefresh = { loadSongs() },
                    onPlay = { playSong(it) },
                    onToggle = {
                        if (player.isPlaying) {
                            player.pause()
                            isPlaying = false
                        } else if (currentSong != null) {
                            player.play()
                            isPlaying = true
                        }
                    }
                )
                1 -> SearchScreen(
                    query = query,
                    onQueryChange = { query = it },
                    songs = filteredSongs,
                    onPlay = { playSong(it) }
                )
                2 -> LibraryScreen(songs = songs, onPlay = { playSong(it) })
                3 -> SettingsScreen()
            }
        }
    }
}

@Composable
private fun HomeScreen(
    songs: List<Song>,
    currentSong: Song?,
    isPlaying: Boolean,
    isLoading: Boolean,
    error: String?,
    onRefresh: () -> Unit,
    onPlay: (Song) -> Unit,
    onToggle: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("BeatNova", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                Text("موسیقی آنلاین", color = Color.LightGray)
            }
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
            }
        }

        if (error != null) {
            Card(
                modifier = Modifier.padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF21171A))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("اتصال به موسیقی آنلاین آماده نیست", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(error, color = Color.LightGray)
                    Spacer(Modifier.height(10.dp))
                    Text("در Codemagic متغیرهای SUPABASE_URL و SUPABASE_ANON_KEY را تنظیم کن.", color = Color.LightGray)
                }
            }
        }

        if (isLoading) {
            Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (songs.isEmpty() && error == null) {
            Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) {
                Text("هنوز آهنگی در سرور قرار نگرفته است.", color = Color.LightGray)
            }
        } else {
            Text("آهنگ‌های آنلاین", color = Color.White, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), fontWeight = FontWeight.Bold)
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(songs, key = { it.id }) { song ->
                    SongRow(song = song, selected = currentSong?.id == song.id, onPlay = { onPlay(song) })
                }
            }
        }

        if (currentSong != null) {
            PlayerBar(song = currentSong, isPlaying = isPlaying, onToggle = onToggle)
        }
    }
}

@Composable
private fun SearchScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    songs: List<Song>,
    onPlay: (Song) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("جستجوی موسیقی", style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("نام آهنگ یا خواننده") }
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(songs, key = { it.id }) { song -> SongRow(song, false, { onPlay(song) }) }
        }
    }
}

@Composable
private fun LibraryScreen(songs: List<Song>, onPlay: (Song) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("کتابخانه", style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (songs.isEmpty()) Text("کتابخانه فعلاً خالی است.", color = Color.LightGray)
        LazyColumn { items(songs, key = { it.id }) { song -> SongRow(song, false, { onPlay(song) }) } }
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("تنظیمات", style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("BeatNova 1.0", color = Color.LightGray)
        Spacer(Modifier.height(8.dp))
        Text(
            if (BuildConfig.SUPABASE_URL.isBlank()) "Supabase: تنظیم نشده" else "Supabase: متصل به پروژه",
            color = Color.LightGray
        )
    }
}

@Composable
private fun SongRow(song: Song, selected: Boolean, onPlay: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .clickable(onClick = onPlay),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF252530) else Color(0xFF15151B))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF30303A)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.LibraryMusic, contentDescription = null, tint = Color.White)
            }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(song.artist, color = Color.LightGray)
            }
            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White)
        }
    }
}

@Composable
private fun PlayerBar(song: Song, isPlaying: Boolean, onToggle: () -> Unit) {
    Surface(tonalElevation = 6.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(song.title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(song.artist, color = Color.LightGray)
            }
            IconButton(onClick = onToggle) {
                Icon(
                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White
                )
            }
        }
    }
}
