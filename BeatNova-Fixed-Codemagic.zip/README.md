# BeatNova

یک اپلیکیشن اندرویدی موسیقی با رابط فارسی و راست‌به‌چپ.

## Build

این پروژه برای Codemagic آماده شده است. فایل `codemagic.yaml` در ریشه پروژه قرار دارد و مستقیماً پروژه Gradle را از ریشه می‌سازد.

نام برنامه: BeatNova
Application ID: com.beatnova.app
Version: 1.0 (1)
