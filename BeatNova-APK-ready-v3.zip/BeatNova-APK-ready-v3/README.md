# BeatNova 1.1.0

نسخه نهایی تستی BeatNova با رابط کاربری حرفه‌ای، جستجو، علاقه‌مندی‌ها، پخش آنلاین با Media3/ExoPlayer و اتصال REST به Supabase.

## Supabase
جدول `songs` باید حداقل این ستون‌ها را داشته باشد:
- `id`
- `title`
- `artist`
- `audio_url`
- `cover_url` (اختیاری)

فقط محتوای قانونی، دارای مجوز یا متعلق به خودتان را قرار دهید.

## Codemagic
فایل `codemagic.yaml` مستقیماً Gradle 8.9 را آماده می‌کند و برای جلوگیری از خطای `CM_KEYSTORE_PATH` به Keystore وابسته نیست؛ خروجی Release با کلید debug استاندارد برای تست روی گوشی امضا می‌شود.

برای انتشار نهایی Google Play، بعداً باید Keystore انتشار ثابت را به پروژه وصل کنیم.
