# BeatNova

BeatNova is an Android music player with a real Media3/ExoPlayer online player.

## Online playback
- A test online MP3 is included.
- You can paste a direct public MP3 URL into the player.
- Supabase Storage public MP3 URLs can be used.

## Build
Codemagic builds a release APK using the temporary debug signing configuration for direct testing.
For Google Play distribution, replace it with a permanent release/upload keystore in Codemagic.

## Important
A release-signed APK installed directly from outside Google Play can still show a Google Play Protect warning. That warning is controlled by Google Play Protect and is not something app code alone can guarantee to remove. Publishing through Google Play is the proper production path.
