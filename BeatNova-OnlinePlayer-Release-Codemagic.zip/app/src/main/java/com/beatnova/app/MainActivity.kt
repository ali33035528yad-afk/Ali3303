package com.beatnova.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay

private const val DEMO_URL = "https://storage.googleapis.com/exoplayer-test-media-0/play.mp3"

private data class Track(
    val title: String,
    val artist: String,
    val url: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BeatNovaApp() }
    }
}

@Composable
private fun BeatNovaApp() {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    val tracks = remember {
        listOf(
            Track("آهنگ تست آنلاین", "BeatNova Demo", DEMO_URL)
        )
    }

    var currentIndex by remember { mutableStateOf(0) }
    var currentTrack by remember { mutableStateOf<Track?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var customUrl by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(state: Int) {
                durationMs = player.duration.coerceAtLeast(0L)
                if (state == Player.STATE_ENDED) {
                    isPlaying = false
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(player) {
        while (true) {
            positionMs = player.currentPosition.coerceAtLeast(0L)
            durationMs = player.duration.coerceAtLeast(0L)
            delay(300)
        }
    }

    fun playTrack(track: Track, index: Int = -1) {
        if (track.url.isBlank()) return
        if (index >= 0) currentIndex = index
        currentTrack = track
        player.setMediaItem(MediaItem.fromUri(Uri.parse(track.url)))
        player.prepare()
        player.play()
    }

    fun togglePlayPause() {
        if (currentTrack == null) {
            playTrack(tracks[currentIndex], currentIndex)
        } else if (player.isPlaying) {
            player.pause()
        } else {
            player.play()
        }
    }

    fun playNext() {
        val next = (currentIndex + 1) % tracks.size
        playTrack(tracks[next], next)
    }

    fun playPrevious() {
        val previous = if (currentIndex == 0) tracks.lastIndex else currentIndex - 1
        playTrack(tracks[previous], previous)
    }

    MaterialTheme {
        androidx.compose.runtime.CompositionLocalProvider(
            LocalLayoutDirection provides LayoutDirection.Rtl
        ) {
            Column(Modifier.fillMaxSize().background(Color(0xFF0F1014))) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (selectedTab) {
                        0 -> HomeScreen(
                            currentTrack = currentTrack,
                            isPlaying = isPlaying,
                            positionMs = positionMs,
                            durationMs = durationMs,
                            onPlay = ::playTrack,
                            onPauseResume = ::togglePlayPause,
                            onNext = ::playNext,
                            onPrevious = ::playPrevious,
                            onSeek = { player.seekTo(it) },
                            customUrl = customUrl,
                            onCustomUrlChange = { customUrl = it },
                            onPlayCustom = {
                                val url = customUrl.trim()
                                if (url.startsWith("http://") || url.startsWith("https://")) {
                                    playTrack(Track("آهنگ آنلاین", "BeatNova Online", url))
                                }
                            }
                        )
                        1 -> HomeScreen(
                            currentTrack = currentTrack,
                            isPlaying = isPlaying,
                            positionMs = positionMs,
                            durationMs = durationMs,
                            onPlay = ::playTrack,
                            onPauseResume = ::togglePlayPause,
                            onNext = ::playNext,
                            onPrevious = ::playPrevious,
                            onSeek = { player.seekTo(it) },
                            customUrl = customUrl,
                            onCustomUrlChange = { customUrl = it },
                            onPlayCustom = {
                                val url = customUrl.trim()
                                if (url.startsWith("http://") || url.startsWith("https://")) {
                                    playTrack(Track("آهنگ آنلاین", "BeatNova Online", url))
                                }
                            },
                            searchMode = true
                        )
                        else -> LibraryScreen(currentTrack, isPlaying, ::togglePlayPause)
                    }
                }

                NavigationBar {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("خانه") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("جستجو") })
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.LibraryMusic, null) }, label = { Text("کتابخانه") })
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    currentTrack: Track?,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onPlay: (Track, Int) -> Unit,
    onPauseResume: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    customUrl: String,
    onCustomUrlChange: (String) -> Unit,
    onPlayCustom: () -> Unit,
    searchMode: Boolean = false
) {
    val demoTrack = Track("آهنگ تست آنلاین", "BeatNova Demo", DEMO_URL)
    val safeDuration = durationMs.coerceAtLeast(1L)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(10.dp))
        Text(
            if (searchMode) "جستجوی موسیقی" else "BeatNova",
            color = Color.White,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            if (searchMode) "لینک مستقیم آهنگ آنلاین را وارد کن" else "پخش واقعی موسیقی از اینترنت 🎧",
            color = Color.LightGray
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF272A35)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("پخش‌کننده آنلاین", color = Color.White, fontWeight = FontWeight.Bold)
                Text(currentTrack?.title ?: "آهنگی انتخاب نشده", color = Color.White)
                Text(currentTrack?.artist ?: "برای تست، پخش را بزن", color = Color.Gray)

                Slider(
                    value = positionMs.coerceIn(0L, safeDuration).toFloat(),
                    onValueChange = { onSeek(it.toLong()) },
                    valueRange = 0f..safeDuration.toFloat(),
                    enabled = durationMs > 0L,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(positionMs), color = Color.Gray)
                    Text(formatTime(durationMs), color = Color.Gray)
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "قبلی", tint = Color.White) }
                    IconButton(
                        onClick = onPauseResume,
                        modifier = Modifier.size(62.dp).background(Color(0xFF7C4DFF), RoundedCornerShape(50))
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            "پخش/توقف",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "بعدی", tint = Color.White) }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF191B22)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("آهنگ آنلاین خودت", color = Color.White, fontWeight = FontWeight.Bold)
                Text("لینک عمومی MP3 از Supabase Storage را اینجا بچسبان.", color = Color.Gray)
                OutlinedTextField(
                    value = customUrl,
                    onValueChange = onCustomUrlChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("لینک مستقیم MP3") }
                )
                Button(onClick = onPlayCustom, modifier = Modifier.fillMaxWidth()) {
                    Text("پخش آهنگ آنلاین")
                }
            }
        }

        Text("آهنگ تست", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF191B22)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(54.dp).background(Color(0xFF303441), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.MusicNote, null, tint = Color.White)
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(demoTrack.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(demoTrack.artist, color = Color.Gray)
                }
                IconButton(onClick = { onPlay(demoTrack, 0) }) {
                    Icon(Icons.Default.PlayArrow, "پخش", tint = Color.White)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun LibraryScreen(currentTrack: Track?, isPlaying: Boolean, onPauseResume: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("کتابخانه من", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("پخش‌کننده آنلاین فعال است.", color = Color.Gray)
        if (currentTrack != null) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF272A35)), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(currentTrack.title, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(currentTrack.artist, color = Color.Gray)
                    }
                    IconButton(onClick = onPauseResume) {
                        Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).toInt().coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}
