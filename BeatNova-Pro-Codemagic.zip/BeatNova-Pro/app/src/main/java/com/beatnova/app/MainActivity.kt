package com.beatnova.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray

private const val SUPABASE_URL = BuildConfig.SUPABASE_URL
private const val SUPABASE_KEY = BuildConfig.SUPABASE_KEY
private const val DEMO_URL = "https://storage.googleapis.com/exoplayer-test-media-0/play.mp3"

private data class Track(val id: Long, val title: String, val artist: String, val url: String, val cover: String?, val duration: Int)

private val Bg = Color(0xFF070912)
private val Panel = Color(0xFF121827)
private val Panel2 = Color(0xFF171D30)
private val Purple = Color(0xFF7C3CFF)
private val Purple2 = Color(0xFFB13CFF)
private val TextWhite = Color(0xFFF7F5FF)
private val TextGray = Color(0xFF9EA4B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BeatNovaApp() }
    }
}

@Composable
private fun BeatNovaApp() {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var current by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var tab by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    var showPlayer by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        try {
            tracks = fetchSongs()
            if (tracks.isEmpty()) tracks = listOf(Track(0, "آهنگ تست آنلاین", "BeatNova Demo", DEMO_URL, null, 0))
        } catch (e: Exception) {
            error = "اتصال به Supabase برقرار نشد"
            tracks = listOf(Track(0, "آهنگ تست آنلاین", "BeatNova Demo", DEMO_URL, null, 0))
        } finally { loading = false }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                duration = player.duration.coerceAtLeast(0L)
                if (state == Player.STATE_ENDED) playing = false
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }

    LaunchedEffect(player) {
        while (true) { position = player.currentPosition.coerceAtLeast(0L); duration = player.duration.coerceAtLeast(0L); delay(250) }
    }

    fun play(track: Track) {
        current = track
        player.setMediaItem(MediaItem.fromUri(Uri.parse(track.url)))
        player.prepare(); player.play(); showPlayer = true
    }
    fun toggle() { if (current == null) play(tracks.firstOrNull() ?: return) else if (player.isPlaying) player.pause() else player.play() }
    fun next() { val i = tracks.indexOfFirst { it.id == current?.id }.coerceAtLeast(0); play(tracks[(i + 1) % tracks.size]) }
    fun prev() { val i = tracks.indexOfFirst { it.id == current?.id }.coerceAtLeast(0); play(tracks[if (i == 0) tracks.lastIndex else i - 1]) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
            Box(Modifier.fillMaxSize().background(Bg)) {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        when (tab) {
                            0 -> HomeScreen(tracks, current, playing, loading, error, ::play, search = search)
                            1 -> SearchScreen(tracks, search, { search = it }, ::play)
                            2 -> LibraryScreen(tracks, ::play)
                            else -> ProfileScreen()
                        }
                    }
                    if (current != null && tab != 3) MiniPlayer(current!!, playing, ::toggle, { showPlayer = true })
                    NavigationBar(containerColor = Color(0xFF0D111C), tonalElevation = 0.dp) {
                        NavItem(0, tab, "خانه", Icons.Default.Home) { tab = 0 }
                        NavItem(1, tab, "جستجو", Icons.Default.Search) { tab = 1 }
                        NavItem(2, tab, "کتابخانه", Icons.Default.LibraryMusic) { tab = 2 }
                        NavItem(3, tab, "من", Icons.Default.Person) { tab = 3 }
                    }
                }
                if (showPlayer && current != null) FullPlayer(current!!, playing, position, duration, ::toggle, ::next, ::prev, { player.seekTo(it) }) { showPlayer = false }
            }
        }
    }
}

@Composable private fun NavItem(index: Int, tab: Int, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    NavigationBarItem(selected = tab == index, onClick = onClick, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 11.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple2, selectedTextColor = Purple2, indicatorColor = Color(0x332E1B58), unselectedIconColor = TextGray, unselectedTextColor = TextGray))
}

@Composable private fun HomeScreen(tracks: List<Track>, current: Track?, playing: Boolean, loading: Boolean, error: String?, play: (Track) -> Unit, search: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("BeatNova", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = TextWhite); Text("موسیقی، همیشه با تو", color = TextGray, fontSize = 13.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null, tint = TextWhite) }; IconButton(onClick = {}) { Icon(Icons.Default.Search, null, tint = TextWhite) } }
        }
        Box(Modifier.fillMaxWidth().height(185.dp).clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(Color(0xFF25105C), Color(0xFF7319C8), Color(0xFF151A45))))) {
            Column(Modifier.padding(22.dp).fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Column { Text("Music Connects", color = TextWhite, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("موسیقی را با ما نزدیک‌تر تجربه کن", color = Color(0xFFE3D9FF), fontSize = 14.sp) }
                Button(onClick = { tracks.firstOrNull()?.let(play) }, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("شروع پخش") }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Quick("♫", "پلی‌لیست‌ها"); Quick("♨", "برترین‌ها"); Quick("☆", "علاقه‌مندی"); Quick("♡", "جدیدها")
        }
        Text("جدیدترین آهنگ‌ها", color = TextWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        if (loading) Text("در حال دریافت آهنگ‌ها از Supabase...", color = TextGray)
        if (error != null) Text(error, color = Color(0xFFFF8A9A), fontSize = 12.sp)
        tracks.forEachIndexed { i, t -> TrackRow(t, i, current?.id == t.id && playing, play) }
    }
}

@Composable private fun Quick(icon: String, title: String) { Box(Modifier.weight(1f).height(78.dp).clip(RoundedCornerShape(18.dp)).background(Panel2), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(icon, color = Purple2, fontSize = 24.sp); Text(title, color = TextGray, fontSize = 11.sp) } } }

@Composable private fun SearchScreen(tracks: List<Track>, search: String, setSearch: (String) -> Unit, play: (Track) -> Unit) {
    val filtered = tracks.filter { it.title.contains(search, true) || it.artist.contains(search, true) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("جستجو", color = TextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = search, onValueChange = setSearch, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("نام آهنگ یا خواننده...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF30364A), focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, cursorColor = Purple))
        Spacer(Modifier.height(20.dp)); Text("آهنگ‌ها", color = TextWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) { itemsIndexed(filtered) { i, t -> TrackRow(t, i, false, play) } }
    }
}

@Composable private fun LibraryScreen(tracks: List<Track>, play: (Track) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("کتابخانه", color = TextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold); IconButton(onClick = {}) { Icon(Icons.Default.Add, null, tint = TextWhite) } }; Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(true, "پلی‌لیست‌ها"); FilterChip(false, "محبوب"); FilterChip(false, "همه") }; Spacer(Modifier.height(14.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { itemsIndexed(tracks) { i, t -> TrackRow(t, i, false, play) } } }
}
@Composable private fun FilterChip(selected: Boolean, text: String) { Surface(shape = RoundedCornerShape(50), color = if (selected) Purple else Panel2) { Text(text, color = TextWhite, modifier = Modifier.padding(horizontal = 15.dp, vertical = 8.dp), fontSize = 12.sp) } }

@Composable private fun ProfileScreen() { Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Spacer(Modifier.height(35.dp)); Box(Modifier.size(92.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Purple2))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(48.dp)) }; Spacer(Modifier.height(12.dp)); Text("BeatNova User", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("عاشق موسیقی 👑", color = TextGray); Spacer(Modifier.height(30.dp)); listOf("پلی‌لیست‌های من", "دانلودها", "علاقه‌مندی‌ها", "تاریخچه پخش", "تنظیمات").forEach { item -> Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), color = Panel, shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(17.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(item, color = TextWhite); Icon(Icons.Default.ChevronLeft, null, tint = TextGray) } } } } }

@Composable private fun TrackRow(track: Track, index: Int, isPlaying: Boolean, play: (Track) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(if (isPlaying) Color(0xFF1E1833) else Panel).clickable { play(track) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        AlbumArt(track.cover, index)
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(track.title, color = TextWhite, fontWeight = FontWeight.SemiBold, maxLines = 1); Text(track.artist, color = TextGray, fontSize = 12.sp, maxLines = 1) }
        IconButton(onClick = { play(track) }, modifier = Modifier.size(42.dp).clip(CircleShape).background(Purple)) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White) }
    }
}

@Composable private fun AlbumArt(url: String?, index: Int) { if (!url.isNullOrBlank()) AsyncImage(model = url, contentDescription = null, modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop) else Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Purple, Color(0xFF141D5A)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(28.dp)) } }

@Composable private fun MiniPlayer(track: Track, playing: Boolean, toggle: () -> Unit, open: () -> Unit) { Row(Modifier.fillMaxWidth().height(68.dp).background(Color(0xFF151A29)).clickable { open() }.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) { AlbumArt(track.cover, 0); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(track.title, color = TextWhite, maxLines = 1); Text(track.artist, color = TextGray, fontSize = 11.sp) }; IconButton(onClick = toggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White) } }
}

@Composable private fun FullPlayer(track: Track, playing: Boolean, position: Long, duration: Long, toggle: () -> Unit, next: () -> Unit, prev: () -> Unit, seek: (Long) -> Unit, close: () -> Unit) {
    Dialog(onDismissRequest = close) { Surface(Modifier.fillMaxSize(), color = Bg) { Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { IconButton(onClick = close) { Icon(Icons.Default.KeyboardArrowDown, null, tint = TextWhite) }; IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, null, tint = TextWhite) } }; Spacer(Modifier.height(25.dp)); if (!track.cover.isNullOrBlank()) AsyncImage(model = track.cover, contentDescription = null, modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)), contentScale = ContentScale.Crop) else Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF31116B), Color(0xFF9A2CF3), Color(0xFF111B53)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(100.dp)) }; Spacer(Modifier.height(25.dp)); Text(track.title, color = TextWhite, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text(track.artist, color = TextGray, fontSize = 15.sp); Spacer(Modifier.height(15.dp)); Slider(value = position.coerceIn(0L, duration.coerceAtLeast(1L)).toFloat(), onValueChange = { seek(it.toLong()) }, valueRange = 0f..duration.coerceAtLeast(1L).toFloat(), colors = SliderDefaults.colors(thumbColor = Purple2, activeTrackColor = Purple)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatTime(position), color = TextGray, fontSize = 11.sp); Text(formatTime(duration), color = TextGray, fontSize = 11.sp) }; Spacer(Modifier.height(20.dp)); Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = prev) { Icon(Icons.Default.SkipPrevious, null, tint = TextWhite, modifier = Modifier.size(34.dp)) }; IconButton(onClick = toggle, modifier = Modifier.size(74.dp).clip(CircleShape).background(Purple)) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(38.dp)) }; IconButton(onClick = next) { Icon(Icons.Default.SkipNext, null, tint = TextWhite, modifier = Modifier.size(34.dp)) } }; Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { Text("♡ علاقه‌مندی", color = TextGray); Text("☷ افزودن به پلی‌لیست", color = TextGray); Text("⇩ دانلود", color = TextGray) } } } }
}

private fun formatTime(ms: Long): String { val total = (ms / 1000).coerceAtLeast(0); return "%02d:%02d".format(total / 60, total % 60) }

private suspend fun fetchSongs(): List<Track> = withContext(Dispatchers.IO) {
    if (SUPABASE_URL.isBlank() || SUPABASE_KEY.isBlank()) return@withContext emptyList()
    val url = java.net.URL("$SUPABASE_URL/rest/v1/songs?select=id,title,artist,audio_url,cover_url,duration&order=id.desc")
    val conn = url.openConnection() as java.net.HttpURLConnection
    conn.requestMethod = "GET"; conn.setRequestProperty("apikey", SUPABASE_KEY); conn.setRequestProperty("Authorization", "Bearer $SUPABASE_KEY"); conn.connectTimeout = 12000; conn.readTimeout = 12000
    if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
    val json = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
    buildList { for (i in 0 until json.length()) { val o = json.getJSONObject(i); add(Track(o.optLong("id"), o.optString("title"), o.optString("artist"), o.optString("audio_url"), o.optString("cover_url").takeIf { it.isNotBlank() && it != "null" }, o.optInt("duration"))) } }
}
