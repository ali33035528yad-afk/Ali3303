# BeatNova 1.2

Modern Persian RTL neon-purple music UI with Supabase database integration and Media3 online playback.

The app reads public rows from `public.songs` using the `SUPABASE_URL` and `SUPABASE_KEY` environment variables at build time. Do not put a Supabase service-role key in the app; use the publishable/anon key with RLS.
