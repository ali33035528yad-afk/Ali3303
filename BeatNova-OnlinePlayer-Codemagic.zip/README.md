# BeatNova

Android Compose music app with online playback of a test track stored in Supabase Storage.

## Test track
The app currently points to:
- Sash - Adelante
- Supabase public object URL in `MainActivity.kt`

The bucket must be public for the `/storage/v1/object/public/...` URL to work.

## Build
The existing `codemagic.yaml` builds a debug APK with Gradle 8.9.
